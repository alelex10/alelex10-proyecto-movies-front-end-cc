This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-toast/

Introducing Super Toast: The Font That's Lit!

Spread the joy with Super Toast, a font so extraordinarily playful it'll have your words dancing on the page.